# League Discord Bot
Upload and deploy using Railway.